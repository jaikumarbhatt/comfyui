from .imageTiling import Tiling
NODE_CLASS_MAPPINGS = {"Tiling": Tiling}
NODE_DISPLAY_NAME_MAPPINGS = {"TilingofImage": "Tiling of Image"}
__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS']